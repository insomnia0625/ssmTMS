package com.cqupt.service;

public interface PurchaseListService {
}
