package com.cqupt.service;

import org.springframework.stereotype.Service;

@Service
public class PurchaseListServiceImpl implements PurchaseListService{
}
