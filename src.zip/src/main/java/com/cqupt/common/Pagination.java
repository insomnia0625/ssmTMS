package com.cqupt.common;

import lombok.Data;

@Data
public class Pagination {
    private Integer page;
    private Integer limit;
}
