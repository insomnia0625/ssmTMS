package com.cqupt.common;

import lombok.Data;

@Data
public class Result {
    private int code;
    private String msg;
}
